<?php
/**
 * Template Name: Weight Loss Treatment
 *
 * @package Easy_Pharmacy_Theme
 */

get_header(); ?>

  <!-- ============================================
       HERO SECTION
       ============================================ -->
  <section class="wl-hero-section">
    <div class="wl-hero-bg"></div>
    <div class="wl-hero-dots"></div>
    <div class="wl-hero-glow-1"></div>
    <div class="wl-hero-glow-2"></div>

    <div class="section-container">
      <div class="wl-hero-grid">

        <!-- Left: Content -->
        <div class="wl-hero-content">
          <div class="section-badge">
            <span class="pulse-dot">
              <span></span>
              <span></span>
            </span>
            <span class="section-badge-text">MEDICAL WEIGHT LOSS</span>
          </div>

          <h1 class="wl-hero-title">
            <span class="gradient-text">Mounjaro & Wegovy</span> weight loss that works when diets have failed
          </h1>

          <p class="wl-hero-description">
            Prescription Mounjaro and Wegovy (GLP-1 treatments) with expert guidance and face-to-face support right here in Ashford. No remote consultations—real care from someone who knows your name.
          </p>

          <div class="wl-hero-actions">
            <a href="#calculator" class="cta-button primary-cta">
              Book Consultation
              <i class="fas fa-arrow-right"></i>
            </a>
            <a href="tel:01784255222" class="cta-button secondary-cta">
              <i class="fas fa-phone"></i>
              Call 01784 255 222
            </a>
          </div>

          <!-- Testimonial Card -->
          <div class="wl-hero-testimonial">
            <div class="wl-hero-testimonial-quote-icon">
              <i class="fas fa-quote-left"></i>
            </div>
            <p class="wl-hero-testimonial-quote">
              "I travel 40 miles every month to see Dilip for my weight loss consultations– he's that good. Would never go anywhere else."
            </p>
            <div class="wl-hero-testimonial-footer">
              <div class="wl-hero-testimonial-author">
                <p class="wl-hero-testimonial-name">Ashford Patient</p>
                <p class="wl-hero-testimonial-location">Ashford</p>
              </div>
              <div class="star-row">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Image Grid -->
        <div class="wl-hero-images">
          <div class="wl-hero-image wl-hero-image-1">
            <img src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&h=400&fit=crop" alt="Weight loss success story" />
            <div class="wl-hero-image-overlay"></div>
          </div>
          <div class="wl-hero-image wl-hero-image-2">
            <img src="https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=400&h=400&fit=crop" alt="Healthy lifestyle transformation" />
            <div class="wl-hero-image-overlay"></div>
          </div>
          <div class="wl-hero-image wl-hero-image-3">
            <img src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800&h=400&fit=crop" alt="Fitness and wellness journey" />
            <div class="wl-hero-image-overlay"></div>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ============================================
       STATS BAR
       ============================================ -->
  <section class="wl-stats-section">
    <div class="wl-stats-shimmer"></div>
    <div class="wl-stats-dots"></div>
    <div class="section-container">
      <div class="wl-stats-grid">

        <div class="wl-stat-item">
          <div class="wl-stat-icon">
            <i class="fas fa-star"></i>
          </div>
          <div class="wl-stat-content">
            <p class="wl-stat-number">4.7★</p>
            <p class="wl-stat-label">Google Rating</p>
          </div>
        </div>

        <div class="wl-stat-item">
          <div class="wl-stat-icon">
            <i class="fas fa-users"></i>
          </div>
          <div class="wl-stat-content">
            <p class="wl-stat-number">300+</p>
            <p class="wl-stat-label">Patients Helped</p>
          </div>
        </div>

        <div class="wl-stat-item desktop-only">
          <div class="wl-stat-icon">
            <i class="fas fa-shield-halved"></i>
          </div>
          <div class="wl-stat-content">
            <p class="wl-stat-number">GPhC</p>
            <p class="wl-stat-label">Registered</p>
          </div>
        </div>

        <div class="wl-stat-item">
          <div class="wl-stat-icon">
            <i class="fas fa-award"></i>
          </div>
          <div class="wl-stat-content">
            <p class="wl-stat-number">30+</p>
            <p class="wl-stat-label">Years Experience</p>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ============================================
       RESULTS SHOWCASE
       ============================================ -->
  <section class="wl-results-section">
    <div class="section-container">

      <div class="wl-results-header">
        <div class="section-badge">
          <span class="pulse-dot">
            <span></span>
            <span></span>
          </span>
          <span class="section-badge-text">REAL RESULTS</span>
        </div>
        <h2 class="wl-results-title">Real Mounjaro & Wegovy results in Ashford</h2>
        <p class="wl-results-description">
          Ashford patients using Mounjaro or Wegovy lose an average of 10-15% of their body weight in 12 months with our personalised programmes.
        </p>
      </div>

      <div class="wl-results-grid">

        <!-- Card 1: Satisfaction -->
        <div class="wl-results-card">
          <div class="star-row wl-results-stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p class="wl-results-number gradient-text">4.7/5</p>
          <p class="wl-results-label">Patient satisfaction</p>
          <p class="wl-results-sublabel">Based on verified reviews</p>
        </div>

        <!-- Card 2: Featured Weight Loss -->
        <div class="wl-results-card wl-results-card-featured">
          <div class="wl-results-featured-badge">Most Important</div>
          <div class="wl-results-featured-bg-dots"></div>
          <div class="wl-results-featured-circle"></div>
          <div class="wl-results-featured-square"></div>
          <div class="wl-results-featured-icon">
            <i class="fas fa-chart-line"></i>
          </div>
          <p class="wl-results-featured-number">10-15%</p>
          <p class="wl-results-featured-label">Average weight loss</p>
          <p class="wl-results-featured-sublabel">In 12 months</p>
        </div>

        <!-- Card 3: Patients Helped -->
        <div class="wl-results-card">
          <div class="wl-results-icon">
            <i class="fas fa-user-group"></i>
          </div>
          <p class="wl-results-number gradient-text">300+</p>
          <p class="wl-results-label">Ashford residents</p>
          <p class="wl-results-sublabel">Successfully helped</p>
        </div>

      </div>

      <p class="wl-results-disclaimer">
        <i class="fas fa-info-circle"></i>
        Results vary by individual. Weight loss depends on adherence to treatment, lifestyle changes, and individual metabolism.
      </p>

    </div>
  </section>

  <!-- ============================================
       FEATURES SECTION
       ============================================ -->
  <section class="wl-features-section">
    <div class="section-container">

      <div class="wl-features-header">
        <div class="section-badge">
          <span class="pulse-dot">
            <span></span>
            <span></span>
          </span>
          <span class="section-badge-text">Why Choose Us</span>
        </div>
        <h2 class="wl-features-title">The Easy Pharmacy Difference</h2>
        <div class="wl-features-divider"></div>
        <p class="wl-features-description">Real face-to-face support. Expert guidance. Proven results.</p>
      </div>

      <div class="wl-features-grid">

        <!-- Left: Image -->
        <div class="wl-features-image-wrapper">
          <div class="wl-features-image-bg-circle"></div>
          <div class="wl-features-image-card">
            <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&h=700&fit=crop" alt="Weight loss success patient" />
          </div>
          <div class="wl-features-badge wl-features-badge-rating">
            <div class="star-row">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
            </div>
            <p class="wl-features-badge-text">4.7/5</p>
          </div>
          <div class="wl-features-badge wl-features-badge-patients">
            <i class="fas fa-users"></i>
            <p class="wl-features-badge-text">300+ Patients Helped</p>
          </div>
        </div>

        <!-- Right: Features -->
        <div class="wl-features-content">

          <div class="wl-features-card">
            <div class="wl-features-card-icon">
              <i class="fas fa-check"></i>
            </div>
            <div class="wl-features-card-text">
              <h3 class="wl-features-card-title">No GP referral needed</h3>
              <p class="wl-features-card-description">Book directly with our independent prescriber. Start your journey this week, not in months.</p>
            </div>
          </div>

          <div class="wl-features-card">
            <div class="wl-features-card-icon">
              <i class="fas fa-users"></i>
            </div>
            <div class="wl-features-card-text">
              <h3 class="wl-features-card-title">Face-to-face care, every month</h3>
              <p class="wl-features-card-description">See the same pharmacist who knows your name. No video calls—real, local support.</p>
            </div>
          </div>

          <div class="wl-features-card">
            <div class="wl-features-card-icon">
              <i class="fas fa-clipboard-check"></i>
            </div>
            <div class="wl-features-card-text">
              <h3 class="wl-features-card-title">Evidence-based approach</h3>
              <p class="wl-features-card-description">Clinically-proven treatment combined with tailored nutrition and lifestyle guidance.</p>
            </div>
          </div>

          <div class="wl-features-actions">
            <a href="#calculator" class="cta-button primary-cta">
              Start Your Journey
              <i class="fas fa-arrow-right"></i>
            </a>
            <a href="tel:01784255222" class="cta-button secondary-cta">
              <i class="fas fa-phone"></i>
              Call Us
            </a>
          </div>

          <div class="wl-features-credentials">
            <div class="wl-features-credential">
              <i class="fas fa-shield-halved"></i>
              <span>GPhC Registered</span>
            </div>
            <div class="wl-features-credential">
              <i class="fas fa-user-doctor"></i>
              <span>Independent Prescriber</span>
            </div>
            <div class="wl-features-credential">
              <i class="fas fa-award"></i>
              <span>30+ Years</span>
            </div>
          </div>

          <div class="wl-features-social-proof">
            <div class="wl-features-avatars">
              <div class="wl-features-avatar">JD</div>
              <div class="wl-features-avatar">SM</div>
              <div class="wl-features-avatar">PF</div>
              <div class="wl-features-avatar-badge">300+</div>
            </div>
            <p class="wl-features-social-text">300+ Ashford residents have started their journey</p>
          </div>

        </div>

      </div>

    </div>
  </section>

  <!-- ============================================
       CTA BAR (Reused from homepage style)
       ============================================ -->
  <section class="wl-cta-bar">
    <div class="wl-cta-bar-shimmer"></div>
    <div class="section-container">
      <div class="wl-cta-bar-content">
        <div class="wl-cta-bar-text">
          <h3 class="wl-cta-bar-title">Ready to transform your health?</h3>
          <p class="wl-cta-bar-subtitle">Book your consultation with Dilip today</p>
        </div>
        <a href="#calculator" class="cta-button primary-cta wl-cta-bar-button">
          Book Consultation
          <i class="fas fa-arrow-right"></i>
        </a>
      </div>
    </div>
  </section>

  <!-- ============================================
       JOURNEY STEPS
       ============================================ -->
  <section class="wl-journey-section">
    <div class="section-container">

      <div class="wl-journey-header">
        <div class="section-badge">
          <span class="pulse-dot">
            <span></span>
            <span></span>
          </span>
          <span class="section-badge-text">HOW WE SUPPORT YOU</span>
        </div>
        <h2 class="wl-journey-title">Your path to lasting weight loss</h2>
        <p class="wl-journey-description">
          A structured, evidence-based approach with regular face-to-face support every step of the way.
        </p>
      </div>

      <!-- Step 1 -->
      <div class="wl-journey-step wl-journey-step-left">
        <div class="wl-journey-step-content">
          <div class="wl-journey-step-number">1</div>
          <div class="wl-journey-step-icon">
            <i class="fas fa-calendar-check"></i>
          </div>
          <h3 class="wl-journey-step-title">Initial consultation</h3>
          <p class="wl-journey-step-description">
            Meet with our expert team at our Ashford pharmacy for a comprehensive health assessment. We'll discuss your goals, medical history, and create a personalised plan that works for you.
          </p>
          <div class="wl-journey-step-meta">
            <i class="fas fa-clock"></i>
            <span>30-45 minutes | Private consultation</span>
          </div>
        </div>
        <div class="wl-journey-step-image">
          <img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=500&fit=crop" alt="Initial consultation at Easy Pharmacy" />
        </div>
      </div>

      <!-- Step 2 -->
      <div class="wl-journey-step wl-journey-step-right">
        <div class="wl-journey-step-image">
          <img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=600&h=500&fit=crop" alt="Mounjaro and Wegovy prescription" />
          <div class="wl-journey-step-floating-badge">
            <i class="fas fa-bolt"></i>
            <span>Same Day</span>
          </div>
        </div>
        <div class="wl-journey-step-content">
          <div class="wl-journey-step-number">2</div>
          <div class="wl-journey-step-icon">
            <i class="fas fa-pills"></i>
          </div>
          <h3 class="wl-journey-step-title">Begin Mounjaro or Wegovy treatment</h3>
          <p class="wl-journey-step-description">
            If suitable, we'll prescribe Mounjaro, Wegovy, or other GLP-1 treatments. You'll receive clear instructions and guidance on what to expect from your Ashford weight loss programme.
          </p>
          <div class="wl-journey-step-meta">
            <i class="fas fa-bolt"></i>
            <span>Same-day prescription available</span>
          </div>
        </div>
      </div>

      <!-- Step 3 -->
      <div class="wl-journey-step wl-journey-step-left">
        <div class="wl-journey-step-content">
          <div class="wl-journey-step-number">3</div>
          <div class="wl-journey-step-icon">
            <i class="fas fa-user-doctor"></i>
          </div>
          <h3 class="wl-journey-step-title">Monthly check-ins</h3>
          <p class="wl-journey-step-description">
            Pop into the pharmacy for face-to-face appointments. We'll monitor your progress, adjust medication if needed, and provide ongoing encouragement. You're never doing this alone.
          </p>
          <div class="wl-journey-step-meta">
            <i class="fas fa-calendar"></i>
            <span>Monthly appointments</span>
          </div>
        </div>
        <div class="wl-journey-step-image">
          <img src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=600&h=500&fit=crop" alt="Monthly check-in appointment" />
          <div class="wl-journey-step-floating-badge wl-journey-step-floating-badge-heart">
            <i class="fas fa-heart"></i>
          </div>
        </div>
      </div>

      <!-- Step 4 -->
      <div class="wl-journey-step wl-journey-step-right">
        <div class="wl-journey-step-image">
          <img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=500&fit=crop" alt="Weight loss goal achievement" />
          <div class="wl-journey-step-floating-badge wl-journey-step-floating-badge-trophy">
            <i class="fas fa-trophy"></i>
          </div>
        </div>
        <div class="wl-journey-step-content">
          <div class="wl-journey-step-number">4</div>
          <div class="wl-journey-step-icon">
            <i class="fas fa-trophy"></i>
          </div>
          <h3 class="wl-journey-step-title">Reach your goals</h3>
          <p class="wl-journey-step-description">
            With consistent support and proven medical treatments, most patients reach their target weight within 12 months. We'll help you maintain results long-term.
          </p>
          <div class="wl-journey-step-meta">
            <i class="fas fa-infinity"></i>
            <span>Ongoing maintenance support</span>
          </div>
        </div>
      </div>

    </div>
  </section>

  <!-- ============================================
       CALCULATOR SECTION
       ============================================ -->
  <section class="wl-calculator-section" id="calculator">
    <div class="section-container">

      <div class="wl-calculator-header">
        <div class="section-badge">
          <span class="pulse-dot">
            <span></span>
            <span></span>
          </span>
          <span class="section-badge-text">CLINICAL ESTIMATOR</span>
        </div>
        <h2 class="wl-calculator-title">Estimate Your Weight Loss Journey</h2>
        <p class="wl-calculator-description">
          Based on clinical trial data for GLP-1 medications like Mounjaro and Wegovy. See what's medically achievable for you.
        </p>
      </div>

      <div class="wl-calculator-grid">

        <!-- Left: Image -->
        <div class="wl-calculator-image-wrapper">
          <div class="wl-calculator-image-card">
            <img src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&h=800&fit=crop" alt="Weight loss transformation" />
          </div>
          <div class="wl-calculator-badge">
            <div class="star-row">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
            </div>
            <p class="wl-calculator-badge-number">15-20%</p>
            <p class="wl-calculator-badge-text">Avg. Body Weight Loss</p>
          </div>
        </div>

        <!-- Right: Calculator Form -->
        <div class="wl-calculator-form-wrapper">
          <div class="wl-calculator-form-header">
            <i class="fas fa-calculator"></i>
            <h3 class="wl-calculator-form-title">Weight Loss Estimator</h3>
          </div>

          <form class="wl-calculator-form" id="weightLossCalculator">

            <!-- Weight Input -->
            <div class="wl-calculator-input-group">
              <label class="wl-calculator-label">Current Weight</label>
              <div class="wl-calculator-input-wrapper">
                <input type="number" id="weightInput" class="wl-calculator-input" placeholder="Enter weight" min="40" max="300" required />
                <div class="wl-calculator-toggle">
                  <button type="button" class="wl-calculator-toggle-btn wl-calculator-toggle-active" data-unit="kg">kg</button>
                  <button type="button" class="wl-calculator-toggle-btn" data-unit="st">st</button>
                </div>
              </div>
            </div>

            <!-- Height Input -->
            <div class="wl-calculator-input-group">
              <label class="wl-calculator-label">Height</label>
              <div class="wl-calculator-input-wrapper">
                <input type="number" id="heightInput" class="wl-calculator-input" placeholder="Enter height" min="120" max="250" required />
                <div class="wl-calculator-toggle">
                  <button type="button" class="wl-calculator-toggle-btn wl-calculator-toggle-active" data-unit="cm">cm</button>
                  <button type="button" class="wl-calculator-toggle-btn" data-unit="ft">ft/in</button>
                </div>
              </div>
            </div>

            <button type="submit" class="cta-button primary-cta wl-calculator-submit">
              Calculate Potential Results
              <i class="fas fa-arrow-right"></i>
            </button>

          </form>

          <!-- Results Section (Initially Hidden) -->
          <div class="wl-calculator-results" id="calculatorResults" style="display: none;">

            <div class="wl-calculator-results-header">
              <i class="fas fa-chart-line"></i>
              <h4 class="wl-calculator-results-title">Your Estimated Results</h4>
            </div>

            <!-- BMI Card -->
            <div class="wl-calculator-bmi-card">
              <div class="wl-calculator-bmi-circle">
                <span class="wl-calculator-bmi-number" id="bmiNumber">0</span>
              </div>
              <div class="wl-calculator-bmi-text">
                <p class="wl-calculator-bmi-label">Current BMI</p>
                <p class="wl-calculator-bmi-category" id="bmiCategory">Normal</p>
              </div>
            </div>

            <!-- Projection Card -->
            <div class="wl-calculator-projection-card">
              <h5 class="wl-calculator-projection-title">Projected 12-Month Result</h5>
              <p class="wl-calculator-projection-range" id="projectionRange">0 - 0 kg</p>
              <p class="wl-calculator-projection-subtitle">Based on 10-15% weight loss</p>
            </div>

            <!-- Timeline -->
            <div class="wl-calculator-timeline">
              <div class="wl-calculator-timeline-item">
                <div class="wl-calculator-timeline-bar">
                  <div class="wl-calculator-timeline-fill" style="width: 25%;"></div>
                </div>
                <p class="wl-calculator-timeline-label">Month 3</p>
              </div>
              <div class="wl-calculator-timeline-item">
                <div class="wl-calculator-timeline-bar">
                  <div class="wl-calculator-timeline-fill" style="width: 50%;"></div>
                </div>
                <p class="wl-calculator-timeline-label">Month 6</p>
              </div>
              <div class="wl-calculator-timeline-item">
                <div class="wl-calculator-timeline-bar">
                  <div class="wl-calculator-timeline-fill wl-calculator-timeline-fill-full" style="width: 100%;"></div>
                </div>
                <p class="wl-calculator-timeline-label">Month 12</p>
              </div>
            </div>

            <p class="wl-calculator-disclaimer">
              <i class="fas fa-info-circle"></i>
              Results are estimates based on clinical trial data. Individual results may vary.
            </p>

            <a href="book-appointment.html" class="cta-button primary-cta">
              Book Your Consultation
              <i class="fas fa-arrow-right"></i>
            </a>

          </div>

        </div>

      </div>

    </div>
  </section>

  <!-- ============================================
       PHARMACIST SECTION (Reused from homepage)
       ============================================ -->
  <section class="pharmacist-section">
    <div class="section-container">
      <div class="pharmacist-grid">

        <div class="pharmacist-image-wrapper">
          <div class="pharmacist-image-glow"></div>
          <div class="pharmacist-image-card">
            <img src="https://c.animaapp.com/mkl3y6t51Gb5OV/img/uploaded-asset-1769942949376-0.png" alt="Dilip Modhvadia - Lead Pharmacist" class="pharmacist-image" />
            <div class="pharmacist-video-overlay">
              <div class="play-button">
                <div class="play-button-ping"></div>
                <i class="fas fa-play"></i>
              </div>
            </div>
            <div class="pharmacist-video-label">
              <span>Watch Welcome Message</span>
            </div>
          </div>
          <div class="pharmacist-experience-badge">
            <p class="pharmacist-experience-number">15+</p>
            <p class="pharmacist-experience-label">Years Experience</p>
          </div>
        </div>

        <div class="pharmacist-content">
          <div class="section-badge">
            <span class="pulse-dot">
              <span></span>
              <span></span>
            </span>
            <span class="section-badge-text">Your Local Expert</span>
          </div>

          <h2 class="pharmacist-name">Meet Dilip Modhvadia</h2>
          <h3 class="pharmacist-role">Lead Pharmacist &amp; Independent Prescriber</h3>

          <p class="pharmacist-bio">With over 15 years of experience, Dilip leads our clinical team dedicated to providing personalized, accessible healthcare in Ashford. As an Independent Prescriber, he oversees our weight loss service to ensure you receive safe, effective treatments without the wait.</p>

          <p class="pharmacist-quote">"My goal is to make expert healthcare accessible to everyone in Ashford. Whether you're starting a weight loss journey or need health advice, our team is here to support you every step of the way with honest, professional care."</p>

          <div class="pharmacist-credentials">
            <div class="pharmacist-credential">
              <i class="fas fa-certificate"></i>
              <span>GPhC Registered</span>
            </div>
            <div class="pharmacist-credential">
              <i class="fas fa-file-signature"></i>
              <span>Independent Prescriber</span>
            </div>
            <div class="pharmacist-credential">
              <i class="fas fa-weight-scale"></i>
              <span>Weight Loss Specialist</span>
            </div>
          </div>

          <div class="pharmacist-cta">
            <a href="book-appointment.html" class="cta-button primary-cta">
              Start Your Online Consultation
              <i class="fas fa-arrow-right"></i>
            </a>
          </div>

        </div>
      </div>
    </div>
  </section>

  <!-- ============================================
       FAQ SECTION
       ============================================ -->
  <section class="wl-faq-section">
    <div class="section-container">

      <div class="wl-faq-header">
        <div class="section-badge">
          <span class="pulse-dot">
            <span></span>
            <span></span>
          </span>
          <span class="section-badge-text">FREQUENTLY ASKED QUESTIONS</span>
        </div>
        <h2 class="wl-faq-title">Your questions answered</h2>
        <div class="wl-faq-divider"></div>
        <p class="wl-faq-description">Get answers to the most common weight loss questions</p>
      </div>

      <div class="wl-faq-list">

        <!-- FAQ 1 -->
        <div class="wl-faq-item">
          <button class="wl-faq-question" onclick="toggleFAQ(this)">
            <span class="wl-faq-number">1</span>
            <span class="wl-faq-question-text">How much weight can I expect to lose?</span>
            <i class="fas fa-plus wl-faq-icon"></i>
          </button>
          <div class="wl-faq-answer">
            <p>Clinical trials show patients typically lose 15-20% of their body weight over 12 months with GLP-1 treatments like Mounjaro and Wegovy. For example, someone weighing 100kg could lose 15-20kg. Results vary based on adherence to treatment, lifestyle changes, and individual metabolism. Our face-to-face support helps maximize your results.</p>
          </div>
        </div>

        <!-- FAQ 2 -->
        <div class="wl-faq-item">
          <button class="wl-faq-question" onclick="toggleFAQ(this)">
            <span class="wl-faq-number">2</span>
            <span class="wl-faq-question-text">Do I need a GP referral?</span>
            <i class="fas fa-plus wl-faq-icon"></i>
          </button>
          <div class="wl-faq-answer">
            <p>No, you don't need a GP referral. Dilip is an Independent Prescriber, which means he can assess your suitability and prescribe weight loss medication directly. You can book your consultation today and start your journey this week, not in months.</p>
          </div>
        </div>

        <!-- FAQ 3 -->
        <div class="wl-faq-item">
          <button class="wl-faq-question" onclick="toggleFAQ(this)">
            <span class="wl-faq-number">3</span>
            <span class="wl-faq-question-text">What's the difference between Mounjaro and Wegovy?</span>
            <i class="fas fa-plus wl-faq-icon"></i>
          </button>
          <div class="wl-faq-answer">
            <p>Both are GLP-1 treatments, but Mounjaro (tirzepatide) also activates GIP receptors, making it a dual-action medication. Clinical trials show Mounjaro may lead to slightly greater weight loss (up to 22%) compared to Wegovy (semaglutide) at 15-17%. During your consultation, we'll discuss which treatment is best suited to your needs and medical history.</p>
          </div>
        </div>

        <!-- FAQ 4 -->
        <div class="wl-faq-item">
          <button class="wl-faq-question" onclick="toggleFAQ(this)">
            <span class="wl-faq-number">4</span>
            <span class="wl-faq-question-text">Are there any side effects?</span>
            <i class="fas fa-plus wl-faq-icon"></i>
          </button>
          <div class="wl-faq-answer">
            <p>Common side effects include nausea, vomiting, diarrhea, and constipation, especially when starting treatment or increasing doses. These typically improve over time. We start with a low dose and gradually increase it to minimize side effects. During your monthly check-ins, we'll monitor how you're feeling and adjust your treatment if needed.</p>
          </div>
        </div>

        <!-- FAQ 5 -->
        <div class="wl-faq-item">
          <button class="wl-faq-question" onclick="toggleFAQ(this)">
            <span class="wl-faq-number">5</span>
            <span class="wl-faq-question-text">How much does treatment cost?</span>
            <i class="fas fa-plus wl-faq-icon"></i>
          </button>
          <div class="wl-faq-answer">
            <p>Treatment starts from £125 per month, which includes your medication, monthly face-to-face consultations, and ongoing support. The exact cost depends on which medication you're prescribed and the dosage. We'll discuss pricing transparently during your initial consultation—no hidden fees, no surprises.</p>
          </div>
        </div>

        <!-- FAQ 6 -->
        <div class="wl-faq-item">
          <button class="wl-faq-question" onclick="toggleFAQ(this)">
            <span class="wl-faq-number">6</span>
            <span class="wl-faq-question-text">How long does treatment take?</span>
            <i class="fas fa-plus wl-faq-icon"></i>
          </button>
          <div class="wl-faq-answer">
            <p>Most patients see significant results within 3-6 months and reach their target weight within 12 months. However, weight loss is a journey, not a sprint. We'll work with you to create a sustainable plan that fits your lifestyle. Many patients continue treatment for 12-18 months to achieve and maintain their goals.</p>
          </div>
        </div>

      </div>

    </div>
  </section>

  <!-- ============================================
       TESTIMONIALS SECTION
       ============================================ -->
  <section class="wl-testimonials-section">
    <div class="section-container">

      <div class="wl-testimonials-header">
        <div class="section-badge">
          <span class="pulse-dot">
            <span></span>
            <span></span>
          </span>
          <span class="section-badge-text">SUCCESS STORIES</span>
        </div>
        <h2 class="wl-testimonials-title">Real Ashford success stories</h2>
        <div class="wl-testimonials-divider"></div>
        <p class="wl-testimonials-description">See how our patients have transformed their lives with medical weight loss</p>
      </div>

      <div class="wl-testimonials-grid">

        <!-- Testimonial 1 -->
        <div class="wl-testimonial-card">
          <div class="wl-testimonial-circle">
            <span class="wl-testimonial-circle-number">6</span>
          </div>
          <h3 class="wl-testimonial-title">6 Stone Lost</h3>
          <p class="wl-testimonial-quote">
            "Thank you so much for your weight loss service. I've tried everything over the years. With your help, I've finally managed to lose 6 stones!!"
          </p>
          <div class="star-row wl-testimonial-stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p class="wl-testimonial-author">Ashford Patient</p>
        </div>

        <!-- Testimonial 2 -->
        <div class="wl-testimonial-card">
          <div class="wl-testimonial-circle">
            <span class="wl-testimonial-circle-number">4st</span>
          </div>
          <h3 class="wl-testimonial-title">4 Stone Lost</h3>
          <p class="wl-testimonial-quote">
            "I travel 40 miles every month to see Dilip for my weight loss consultations—he's that good. Would never go anywhere else."
          </p>
          <div class="star-row wl-testimonial-stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p class="wl-testimonial-author">Ashford Patient</p>
        </div>

        <!-- Testimonial 3 -->
        <div class="wl-testimonial-card">
          <div class="wl-testimonial-circle">
            <span class="wl-testimonial-circle-number">3st</span>
          </div>
          <h3 class="wl-testimonial-title">3 Stone Lost</h3>
          <p class="wl-testimonial-quote">
            "I cannot thank you enough for helping me lose weight. Not only do I feel and look great, my hip and knee pain is SO much better now I weigh less."
          </p>
          <div class="star-row wl-testimonial-stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p class="wl-testimonial-author">Sheffield Patient</p>
        </div>

      </div>

    </div>
  </section>

  <!-- ============================================
       FINAL CTA SECTION
       ============================================ -->
  <section class="wl-final-cta-section">
    <div class="wl-final-cta-glow-1"></div>
    <div class="wl-final-cta-glow-2"></div>
    <div class="wl-final-cta-circle"></div>
    <div class="wl-final-cta-square"></div>
    <div class="wl-final-cta-dots"></div>

    <div class="section-container">
      <div class="wl-final-cta-content">

        <div class="wl-final-cta-badges">
          <div class="wl-final-cta-badge">
            <i class="fas fa-shield-halved"></i>
            <span>GPhC Registered</span>
          </div>
          <div class="wl-final-cta-badge">
            <i class="fas fa-user-doctor"></i>
            <span>Independent Prescriber</span>
          </div>
          <div class="wl-final-cta-badge">
            <i class="fas fa-users"></i>
            <span>300+ Patients Helped</span>
          </div>
        </div>

        <h2 class="wl-final-cta-title">Ready to start your weight loss journey?</h2>
        <p class="wl-final-cta-description">
          Join 300+ Ashford residents who've transformed their lives with medical weight loss. Book your consultation with Dilip today.
        </p>

        <div class="wl-final-cta-actions">
          <a href="book-appointment.html" class="cta-button primary-cta wl-final-cta-button-white">
            Book Your Consultation
            <i class="fas fa-arrow-right"></i>
          </a>
          <a href="tel:01784255222" class="cta-button secondary-cta wl-final-cta-button-outlined">
            <i class="fas fa-phone"></i>
            Call 01784 255 222
          </a>
        </div>

        <div class="wl-final-cta-checks">
          <div class="wl-final-cta-check">
            <i class="fas fa-check"></i>
            <span>Expert guidance</span>
          </div>
          <div class="wl-final-cta-check">
            <i class="fas fa-check"></i>
            <span>No obligation</span>
          </div>
          <div class="wl-final-cta-check">
            <i class="fas fa-check"></i>
            <span>Same-day appointments</span>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php get_footer(); ?>
